#loads neccesary library
library(caret)
library(ggplot2)
library(tidyverse)
library(leaps)
library(MASS)
#loads neccesary data
dfavgs <- read.csv(file.choose())
dfabs <- read.csv(file.choose())
# Look at the variables that came across:
names(dfavgs)
names(dfabs)


#partitions train test split of the absolute data
set.seed(63)
abs_idx = createDataPartition(dfavgs$v, p = 0.75, list = FALSE)
abs_trn = dfabs[abs_idx, ]
abs_tst = dfabs[-abs_idx, ]




vabs_logit_model <- glm(v ~ hit + X2b + X3b + hr + rbi + lob +
                          hit_a + X2b_a + X3b_a + hr_a + rbi_a + lob_a,
                        data=abs_trn)
summary(vabs_logit_model)
#prediction <- predict(vavg_logit_model, avg_tst, type="response") 
vabs_logit_model$finalModel
library(ggplot2)
library(dplyr)
mast <- read.csv('https://raw.githubusercontent.com/Elkin3456/SSC442/master/mlb20yr_abs.csv')

al_teams <- mast %>% 
  filter(team %in% c("ANA", "BAL", "BOS", "CHA", "CLE", "DET", "HOU", "KCA", "MIN", "NYA", "OAK", "SEA",
                     "TBA", "TEX", "TOR"))

al_teams %>%
  ggplot( aes(x=year_x, y=hits_t, group=team, color=team)) +
  geom_line() + labs(title = "AL Team's Hits Over Time", x= "Year", y="Hits")

al_teams %>%
  ggplot( aes(x=year_x, y=time, group=team, color=team)) +
  geom_line() + labs(title = "AL Team's Game Length Over Time", x="Year", y="Game Length(minutes)")

al_teams %>%
  ggplot( aes(x=year_x, y=att, group=team, color=team)) +
  geom_line() + labs(title = "AL Team's Attendance Over Time", x="Year", y="Attendance")


nl_teams <- mast %>%
  filter(team %in% c("ARI", "ATL", "CHN", "CIN", "COL", "LAN", "MIA", "MIL", "NYN", "PHI", "PIT", "SDN", "SFN", 
                     "SLN", "WAS"))
nl_teams %>%
  ggplot( aes(x=year_x, y=hits_t, group=team, color=team)) +
  geom_line() + labs(title = "NL Team's Hits Over Time", x= "Year", y="Hits")

nl_teams %>%
  ggplot( aes(x=year_x, y=time, group=team, color=team)) +
  geom_line() + labs(title = "NL Team's Game Length Over Time", x="Year", y="Game Length(minutes)")

nl_teams %>%
  ggplot( aes(x=year_x, y=att, group=team, color=team)) +
  geom_line() + labs(title = "NL Team's Attendance Over Time", x="Year", y="Attendance")
